(function(angular) {
  'use strict'; 
    angular.module('myApp', ['ngMaterial','ngRoute','ngMessages']);
})(window.angular);


