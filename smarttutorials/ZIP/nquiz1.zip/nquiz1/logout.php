<?php
session_start();
session_destroy();
header( 'Location: http://localhost/new_quiz/index.php' ) ;
?>

<!---
Site : http:www.smarttutorials.net
Author :muni
--->