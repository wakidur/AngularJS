<?php
session_start();
session_destroy();
header( 'Location: http://localhost/quiztwo/index.php' ) ;
?>

<!---
Site : http:www.smarttutorials.net
Author :muni
--->