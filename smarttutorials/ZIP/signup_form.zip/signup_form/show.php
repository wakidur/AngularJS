<?php
// Write your php script here to update user information in Database
print_r($_POST);

?>