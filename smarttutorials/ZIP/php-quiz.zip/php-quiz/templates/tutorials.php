<div class="col-xs-12  col-sm-3 col-md-3 col-lg-3">
	<h4 class="text-center text-underline">You may also Like Following Tutorials on jQuery AutoComplete:</h4>
	<div class="textwidget">
		<a
			href="http://www.smarttutorials.net/jquery-autocomplete-multiple-fields-using-ajax-php-mysql-example/">
			jQuery Autocomplete Mutiple Fields Using jQuery, Ajax, PHP and MySQL
			<br>
		<br> <img
			src="http://4.bp.blogspot.com/-mFaa6MsQhLc/VJZdqhgOTlI/AAAAAAAADx4/UpT1_wX68to/s1600/jQuery-Autocomplete-Mutiple-Fields-Using-jQuery-Ajax-PHP-and-MySQL.png"
			class="img-responsive">

		</a>
		<hr>
		<a
			href="http://www.smarttutorials.net/jquery-autocomplete-search-using-php-mysql-and-ajax/">
			jQuery Autocomplete Search using PHP, MySQL and Ajax <br>
		<br> <img
			src="http://4.bp.blogspot.com/-HX0NG_VJXyY/VJZeNNGMCjI/AAAAAAAADyA/-5linVGiytY/s1600/jquery-autocomplete-using-php-mysql-ajax.png"
			class="img-responsive">

		</a>
		<hr>
	</div>
</div>
