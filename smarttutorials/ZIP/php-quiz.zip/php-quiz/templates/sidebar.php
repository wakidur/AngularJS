<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 sidebar">   	
	<img src="img/ad.png"/>
</div>