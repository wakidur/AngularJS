<?php
define('FIELDS_MISSING', 'Some Fields Are Missing');
define('PASSWORD_NOT_MATCH', 'Passwords do not match');
define('USER_REGISTRATION_FAIL', 'User registration failed');
define('USER_REGISTRATION_SUCCESS', 'User registration was successful, You may login now');


define('LOGIN_FIELDS_MISSING', 'Email and Password are missing');
define('LOGIN_FAIL', 'Email and Password are mismatch');

define('PASSOWRD_CHANAGE_SUCCESS', 'Password changed successfully.');
