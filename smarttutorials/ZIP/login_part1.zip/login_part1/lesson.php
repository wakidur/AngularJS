<?php require_once 'templates/header.php';?>
	<div class="content">
     	<div class="container">
     		<div class="col-md-8 col-sm-8 col-xs-12">
     			<span style="font-family: Verdana,sans-serif;">Life's Lessons - Why didn't They Teach Me This Stuff At School?</span>
	     		<br><br>
	     		<ul style="text-align: left;">
					<li><span style="font-family: Verdana,sans-serif;">If it doesn't kill you, it really does make you stronger.</span></li>
					<li><span style="font-family: Verdana,sans-serif;">Miracles usually happen when you're not looking.</span></li>
					<li><span style="font-family: Verdana,sans-serif;">When in doubt just take the first step.</span></li>
					<li><span style="font-family: Verdana,sans-serif;">Over prepare and then go with the flow.</span></li>
					<li><span style="font-family: Verdana,sans-serif;">Everything ever created, started with a dream, so dream big. </span></li>
				</ul>
				<br>
     			<div class="embed-responsive embed-responsive-16by9">
				  <iframe src="//www.youtube.com/embed/X84gAushB1w" frameborder="0" allowfullscreen></iframe>
				</div>
				<br><br>
				<p class="text-center">Read More : <a target="_blank" href="http://www.cultivatinghappyness.com/2014/10/lifes-lessons-motivational-video-why.html"> Life Lessions - Cultivating Happyness </a></p>
     		</div>
     		
     		
     		<?php require_once 'templates/sidebar.php';?>
     		
     	</div>
    </div> <!-- /container -->
<?php require_once 'templates/footer.php';?>
	

