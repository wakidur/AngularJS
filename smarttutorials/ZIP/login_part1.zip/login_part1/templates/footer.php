<div class="clearfix"></div>
	<!-- Footer -->
    <footer>
    	<div class="container-fluid">
    		<p class="text-center">Copyright by <a href="http://smarttutorials.net/" target="_blank">smarttutorials.net</a> 2014</p>
    	</div>
    </footer>
    <!-- /Footer -->
  </body>
</html>
<?php ob_end_flush(); ?>